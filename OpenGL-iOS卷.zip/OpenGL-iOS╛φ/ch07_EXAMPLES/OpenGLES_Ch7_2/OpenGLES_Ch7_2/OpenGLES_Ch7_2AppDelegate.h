//
//  OpenGLES_Ch7_2AppDelegate.h
//  OpenGLES_Ch7_2
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch7_2AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
