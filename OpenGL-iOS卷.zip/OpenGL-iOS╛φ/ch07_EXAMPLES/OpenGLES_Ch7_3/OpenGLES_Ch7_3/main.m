//
//  main.m
//  OpenGLES_Ch7_3
//

#import <UIKit/UIKit.h>

#import "OpenGLES_Ch7_3AppDelegate.h"

int main(int argc, char *argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([OpenGLES_Ch7_3AppDelegate class]));
   }
}
