//
//  TECart+viewAdditions.h
//  OpenGLES_Ch12_1
//

#import "TECart.h"

@class UtilityModelEffect;


@interface TECart (viewAdditions)

- (void)drawWithEffect:(UtilityModelEffect *)anEffect;

@end
