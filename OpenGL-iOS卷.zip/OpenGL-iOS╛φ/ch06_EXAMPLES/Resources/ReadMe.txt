Chapter 6 Examples

Use the obj2opengl.pl script to generate .h files from .obj files.

Example: >./obj2opengl.pl -nomove -noscale ./canLight.obj 
