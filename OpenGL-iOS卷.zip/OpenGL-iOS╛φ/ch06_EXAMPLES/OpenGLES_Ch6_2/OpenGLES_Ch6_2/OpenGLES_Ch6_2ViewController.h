//
//  OpenGLES_Ch6_2ViewController.h
//  OpenGLES_Ch6_2
//

#import <GLKit/GLKit.h>


@interface OpenGLES_Ch6_2ViewController : GLKViewController

@end
