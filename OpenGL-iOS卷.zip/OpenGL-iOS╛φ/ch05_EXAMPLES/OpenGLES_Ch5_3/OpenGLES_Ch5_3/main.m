//
//  main.m
//  OpenGLES_Ch5_3
//

#import <UIKit/UIKit.h>

#import "OpenGLES_Ch5_3AppDelegate.h"

int main(int argc, char *argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([OpenGLES_Ch5_3AppDelegate class]));
   }
}
