//
//  OpenGLES_Ch5_5AppDelegate.h
//  OpenGLES_Ch5_5
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch5_5AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
