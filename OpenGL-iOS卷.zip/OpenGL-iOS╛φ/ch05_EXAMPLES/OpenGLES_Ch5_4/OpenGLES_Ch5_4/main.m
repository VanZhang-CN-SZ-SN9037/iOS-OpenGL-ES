//
//  main.m
//  OpenGLES_Ch5_4
//

#import <UIKit/UIKit.h>

#import "OpenGLES_Ch5_4AppDelegate.h"

int main(int argc, char *argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([OpenGLES_Ch5_4AppDelegate class]));
   }
}
