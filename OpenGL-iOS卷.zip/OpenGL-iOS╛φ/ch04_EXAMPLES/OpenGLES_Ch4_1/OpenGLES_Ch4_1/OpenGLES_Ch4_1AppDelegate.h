//
//  OpenGLES_Ch4_1AppDelegate.h
//  OpenGLES_Ch4_1
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch4_1AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
