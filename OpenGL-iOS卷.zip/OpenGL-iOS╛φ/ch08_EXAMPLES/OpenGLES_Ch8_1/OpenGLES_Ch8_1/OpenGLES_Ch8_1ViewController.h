//
//  OpenGLES_Ch8_1ViewController.h
//  OpenGLES_Ch8_1
//

#import <GLKit/GLKit.h>

@interface OpenGLES_Ch8_1ViewController : GLKViewController

@end
