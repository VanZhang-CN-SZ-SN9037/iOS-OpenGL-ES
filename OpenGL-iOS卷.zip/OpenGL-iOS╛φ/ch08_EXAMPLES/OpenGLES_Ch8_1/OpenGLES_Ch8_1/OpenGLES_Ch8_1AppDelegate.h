//
//  OpenGLES_Ch8_1AppDelegate.h
//  OpenGLES_Ch8_1
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch8_1AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
