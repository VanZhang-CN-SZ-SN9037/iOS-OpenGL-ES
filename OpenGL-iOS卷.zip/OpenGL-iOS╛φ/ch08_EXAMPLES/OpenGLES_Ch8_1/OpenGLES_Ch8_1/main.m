//
//  main.m
//  OpenGLES_Ch8_1
//

#import <UIKit/UIKit.h>

#import "OpenGLES_Ch8_1AppDelegate.h"

int main(int argc, char *argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([OpenGLES_Ch8_1AppDelegate class]));
   }
}
