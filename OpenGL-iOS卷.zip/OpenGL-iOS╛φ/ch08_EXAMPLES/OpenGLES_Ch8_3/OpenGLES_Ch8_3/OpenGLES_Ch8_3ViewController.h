//
//  OpenGLES_Ch8_3ViewController.h
//  OpenGLES_Ch8_3
//

#import <GLKit/GLKit.h>

@interface OpenGLES_Ch8_3ViewController : GLKViewController

- (IBAction)takeSelectedEmitterFrom:(UISegmentedControl *)sender;
- (IBAction)takeSelectedTextureFrom:(UISegmentedControl *)sender;

@end
