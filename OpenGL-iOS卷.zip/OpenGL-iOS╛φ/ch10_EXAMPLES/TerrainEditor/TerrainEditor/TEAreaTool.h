//
//  TEAreaTool.h
//  TerrainEditor
//

#import "TETool.h"

@interface TEAreaTool : TETool

@property (strong, nonatomic, readwrite) 
   NSNumber *toolRadius;

@end
