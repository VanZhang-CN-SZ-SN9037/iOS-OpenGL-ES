//
//  OpenGLES_Ch3_2AppDelegate.h
//  OpenGLES_Ch3_2
//

#import <UIKit/UIKit.h>

@interface OpenGLES_Ch3_2AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
